# Skill #11: email-transactional
## Purpose
User communication — welcome, verify, notify, update.
## Must Cover
- Resend + Next.js, React Email templates
- Transactional flows, queue management, Australian Spam Act compliance
## Reference Files: references/resend-setup.md, references/email-templates.md
