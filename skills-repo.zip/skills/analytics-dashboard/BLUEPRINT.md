# Skill #13: analytics-dashboard
## Purpose
Track users, conversions, product metrics.
## Must Cover
- PostHog/Plausible/Vercel Analytics, custom events, funnels
- Privacy-compliant tracking, dashboard components (Recharts), A/B testing
## Reference Files: references/analytics-setup.md, references/dashboard-components.md
