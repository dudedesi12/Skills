# Skill #3: typescript-for-vibers

## Purpose
Make TypeScript work FOR the vibe coder, not against them. Auto-fix types, generate interfaces, explain errors simply.

## Must Cover
- Interface/type generation from any data shape
- Zod schema generation for runtime validation
- Common TS patterns for Next.js (page props, API routes, server actions)
- Supabase generated types usage
- Utility types explained simply (Partial, Pick, Omit, Record)
- Generic patterns that actually matter
- Type error fixes with plain-English explanations
- enum vs union types
- Type narrowing and guards

## Reference Files to Create
- references/common-patterns.md
- references/error-fixes.md — Top 20 TS errors with fixes
- references/zod-patterns.md
