# Skill #6: seo-programmatic
## Purpose
SEO at scale for programmatic pages (like mypr.au's 3,600+ pages).
## Must Cover
- Next.js Metadata API, generateMetadata for dynamic pages
- JSON-LD structured data (FAQ, Article, HowTo, BreadcrumbList)
- Sitemap generation, robots.txt, canonical URLs, OG/Twitter cards
- Internal linking, Core Web Vitals, programmatic page templates
## Reference Files: references/metadata-patterns.md, references/structured-data.md, references/sitemap-generation.md
