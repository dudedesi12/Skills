# Skill #12: scraper-architect
## Purpose
Data collection at scale — government portals, blogs, community.
## Must Cover
- Puppeteer/Playwright patterns, anti-detection, data normalization
- Scheduled scraping with recovery, freshness tracking, robots.txt compliance
- Gemini-powered extraction, multi-agent architecture (5-agent pattern)
## Reference Files: references/scraper-patterns.md, references/gemini-extraction.md
