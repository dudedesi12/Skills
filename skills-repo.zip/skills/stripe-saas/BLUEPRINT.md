# Skill #9: stripe-saas
## Purpose
Complete Stripe for Australian SaaS — subscriptions, webhooks, checkout.
## Must Cover
- Checkout sessions, subscription lifecycle, webhook signature verification
- Customer portal, pricing page, free trial flows, Australian GST
- Statement descriptor, Supabase + Stripe sync
## Reference Files: references/checkout-patterns.md, references/webhook-events.md, references/subscription-lifecycle.md
