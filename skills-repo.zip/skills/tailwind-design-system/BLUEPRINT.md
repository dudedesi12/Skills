# Skill #5: tailwind-design-system
## Purpose
Consistent, branded UI components across all projects.
## Must Cover
- tailwind.config.ts with brand tokens
- Reusable component patterns (card, table, modal, form, nav, sidebar, toast)
- Responsive design (mobile-first), dark mode, animations
- shadcn/ui integration, accessibility (ARIA, focus, screen readers)
- Custom color palette, typography scale
## Reference Files: references/components.md, references/responsive.md, references/accessibility.md
