# Skill #14: mobile-pwa
## Purpose
App-like experience without App Store.
## Must Cover
- Next.js PWA config, service workers, offline caching
- Push notifications, web manifest, install prompt, iOS/Android optimization
## Reference Files: references/pwa-config.md, references/push-notifications.md
