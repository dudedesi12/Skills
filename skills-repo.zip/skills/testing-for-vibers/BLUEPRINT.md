# Skill #10: testing-for-vibers
## Purpose
Auto-generate tests without writing test code manually.
## Must Cover
- Playwright E2E from page descriptions, API route testing
- GitHub Actions CI/CD, smoke tests, Lighthouse CI, DB seeding
## Reference Files: references/playwright-patterns.md, references/github-actions.md
