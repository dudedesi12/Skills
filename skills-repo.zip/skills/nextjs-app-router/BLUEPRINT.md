# Skill #1: nextjs-app-router

## Purpose
The foundational skill for every web project. Encodes Next.js App Router patterns so Claude generates correct, production-ready Next.js code every time.

## Must Cover
- App Router file conventions (page.tsx, layout.tsx, loading.tsx, error.tsx, not-found.tsx, route.ts)
- Server Components vs Client Components — when to use which
- Data fetching patterns (server components, route handlers, server actions)
- Dynamic routes, catch-all routes, route groups
- Middleware (auth, redirects, geolocation)
- ISR / SSG / SSR selection logic based on data freshness
- Metadata API for SEO
- Streaming and Suspense patterns
- Parallel and intercepting routes
- Environment variable conventions (NEXT_PUBLIC_ prefix)
- next.config.js common patterns
- Error boundaries and error handling

## Reference Files to Create
- references/routing-patterns.md — All route types with examples
- references/server-vs-client.md — Decision tree for component type
- references/data-fetching.md — Fetching patterns with Supabase examples
- references/middleware.md — Auth middleware, redirects, headers
- references/troubleshooting.md — Common errors and fixes
