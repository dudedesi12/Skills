# Skill #8: security-hardening
## Purpose
Production security for SaaS apps before launch.
## Must Cover
- Cloudflare Turnstile CAPTCHA, rate limiting, input sanitization
- XSS/CSRF prevention, CSP headers, auth session security
- Env var audit, dependency scanning, admin route protection, CORS
## Reference Files: references/headers-config.md, references/auth-security.md, references/audit-checklist.md
