# Skill #4: deployment-ops

## Purpose
Ship to production without breaking things. Vercel + DNS + env vars + monitoring.

## Must Cover
- Vercel deployment configuration
- vercel.json patterns
- Environment variables (dev vs preview vs production)
- Domain configuration (GoDaddy/Cloudflare → Vercel)
- Build error troubleshooting (top 20 errors)
- Serverless function limits and optimization
- Edge vs Serverless runtime selection
- Preview deployments and branch deploys
- Rollback procedures
- Build caching and optimization
- Monitoring and alerting basics

## Reference Files to Create
- references/vercel-config.md
- references/dns-setup.md
- references/build-errors.md
- references/optimization.md
