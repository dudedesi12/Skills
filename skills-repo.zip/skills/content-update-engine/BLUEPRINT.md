# Skill #15: content-update-engine
## Purpose
Automated content freshness for immigration data that changes constantly.
## Must Cover
- Content versioning, freshness scoring, user notifications
- Regulatory change detection, review queue, timestamps/badges
- Supabase-based audit trail
## Reference Files: references/freshness-scoring.md, references/change-detection.md
