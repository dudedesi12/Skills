# Skill #7: api-integration-patterns
## Purpose
Connect external APIs — Gemini, Stripe, government portals, scrapers.
## Must Cover
- API client wrapper (retry, timeout, rate limiting)
- Webhook handlers (Stripe, Supabase, custom)
- Cron jobs (Vercel Cron), caching (ISR, SWR), secret management
- Gemini API integration (all 3 tiers), request/response logging
## Reference Files: references/api-client.md, references/webhook-handlers.md, references/cron-patterns.md, references/gemini-integration.md
