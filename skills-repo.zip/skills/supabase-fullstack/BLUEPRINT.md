# Skill #2: supabase-fullstack

## Purpose
Complete Supabase patterns for auth, database, realtime, storage, and edge functions.

## Must Cover
- Supabase client setup (server component client vs browser client vs middleware client)
- Auth flows (email/password, OAuth, magic link, OTP)
- Row Level Security policies (common patterns: owner-only, role-based, public read)
- Database schema design with proper types, indexes, foreign keys
- Supabase Realtime subscriptions
- Storage bucket creation and policies
- Edge Functions with Deno
- Migration file generation
- Supabase CLI commands
- Database functions and triggers
- Full-text search setup

## Reference Files to Create
- references/rls-policies.md — 20+ common RLS patterns
- references/auth-patterns.md — Complete auth flows
- references/realtime.md — Subscription patterns
- references/schema-templates.md — Common SaaS schemas
- references/edge-functions.md — Deno patterns
