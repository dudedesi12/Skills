# 🧠 Tanul's Vibe Coder Skill Stack

Custom Claude skills that turn AI into a comprehensive senior dev team.

## Stack (Non-negotiable)
- **Next.js App Router** + **Supabase** + **Vercel** + **Tailwind CSS** + **TypeScript**
- **AI = Gemini API only** (never OpenAI)
- Gemini tiering: `gemini-2.5-pro` for heavy tasks, `gemini-2.0-flash` for user-facing, Flash Lite for classification

## Skills

### 🔴 Critical (Week 1-2)
| # | Skill | Purpose |
|---|-------|---------|
| 1 | `nextjs-app-router` | Core framework patterns, routing, server/client components |
| 2 | `supabase-fullstack` | Auth, RLS, Realtime, Edge Functions, migrations |
| 3 | `typescript-for-vibers` | Type safety without coding knowledge |
| 4 | `deployment-ops` | Vercel deploy, DNS, env vars, troubleshooting |

### 🟡 High Impact (Week 3-4)
| # | Skill | Purpose |
|---|-------|---------|
| 5 | `tailwind-design-system` | Brand tokens, reusable components, responsive |
| 6 | `seo-programmatic` | Meta tags, JSON-LD, sitemaps, programmatic pages |
| 7 | `api-integration-patterns` | External APIs, webhooks, cron, caching |
| 8 | `security-hardening` | CAPTCHA, rate limiting, XSS, CSP, auth security |

### 🟢 Force Multipliers (Month 2)
| # | Skill | Purpose |
|---|-------|---------|
| 9 | `stripe-saas` | Subscriptions, webhooks, checkout, GST |
| 10 | `testing-for-vibers` | Auto-generated E2E tests, CI/CD |
| 11 | `email-transactional` | Resend/React Email templates, flows |
| 12 | `scraper-architect` | Data extraction, anti-detection, Gemini parsing |
| 13 | `analytics-dashboard` | Tracking, funnels, dashboards |
| 14 | `mobile-pwa` | PWA config, offline, push notifications |
| 15 | `content-update-engine` | Freshness scoring, regulatory change detection |

## How to Build

Open Claude Code in this repo and say:

> Build skill #1 `nextjs-app-router`. Read CLAUDE_CODE_INSTRUCTIONS.md and the blueprint in skills/nextjs-app-router/BLUEPRINT.md. Generate the full SKILL.md with reference files.

Repeat for each skill.
