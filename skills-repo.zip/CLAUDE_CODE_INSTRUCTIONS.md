# Instructions for Claude Code

## Context
You are building custom Claude skills for a vibe coder (non-traditional developer) who builds web apps using AI-assisted workflows. Every skill must assume ZERO coding knowledge from the user.

## Non-Negotiable Stack
- Next.js App Router (latest)
- Supabase (Auth, Database, Realtime, Storage, Edge Functions)
- Vercel (deployment)
- Tailwind CSS
- TypeScript
- Gemini API only (never OpenAI)
  - gemini-2.5-pro → heavy cron/PDF scraping
  - gemini-2.0-flash → user-facing and grounded search
  - Flash Lite → classification

## Skill Architecture

Each skill folder must follow this structure:
```
skill-name/
├── SKILL.md          # Main instruction file (under 500 lines)
├── BLUEPRINT.md      # What to build (input for Claude Code)
└── references/       # Detailed docs loaded on-demand
    ├── patterns.md
    ├── examples.md
    └── troubleshooting.md
```

## SKILL.md Requirements

### Frontmatter (YAML)
```yaml
---
name: skill-name
description: >-
  Pushy, comprehensive trigger description. Include ALL phrases
  that should activate this skill. Err on the side of over-triggering.
---
```

### Body Rules
1. **Assume zero coding knowledge** — explain every decision simply
2. **Production-ready code only** — no placeholders, no TODOs
3. **Copy-paste ready** — user should be able to use output directly
4. **Stack-locked** — always use Next.js App Router + Supabase + Vercel + Tailwind + TS
5. **Include file paths** — always show where code goes (e.g., `app/api/route.ts`)
6. **Error handling included** — never skip try/catch, loading states, error boundaries
7. **Security by default** — RLS, input validation, env var checks baked in
8. **Reference files for depth** — keep SKILL.md under 500 lines, offload details to references/

### Description Writing (Critical for Triggering)
Make descriptions PUSHY. Include:
- Primary use cases
- Edge case triggers
- Related keywords the user might say
- "Even if they don't explicitly mention X" patterns

Example:
> Use this skill whenever the user mentions database, auth, users, login, signup, RLS,
> row level security, Supabase, tables, migrations, policies, realtime, subscriptions,
> storage, buckets, edge functions, or any data modeling task — even if they don't
> explicitly say "Supabase".

## Build Order
Build skills in this order (dependencies flow downward):
1. nextjs-app-router (foundation)
2. typescript-for-vibers (used by everything)
3. supabase-fullstack (data layer)
4. deployment-ops (shipping)
5. tailwind-design-system (UI)
6. security-hardening (protection)
7. api-integration-patterns (external services)
8. seo-programmatic (growth)
9. stripe-saas (revenue)
10. email-transactional (communication)
11. scraper-architect (data)
12. testing-for-vibers (quality)
13. analytics-dashboard (insights)
14. mobile-pwa (reach)
15. content-update-engine (freshness)

## Quality Checklist
Before marking a skill complete:
- [ ] SKILL.md under 500 lines
- [ ] Description is pushy and comprehensive
- [ ] All code uses the non-negotiable stack
- [ ] No OpenAI references anywhere
- [ ] File paths included for all code blocks
- [ ] Error handling in every code example
- [ ] References/ folder has supporting docs
- [ ] A non-coder can follow every instruction
