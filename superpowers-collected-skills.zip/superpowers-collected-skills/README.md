# Superpowers - Collected Productivity Skills

Collected from [obra/superpowers](https://github.com/obra/superpowers) - a composable skills framework for AI-assisted development that 100x productivity.

## What's Inside

### Skills (14 total)
| Skill | Purpose |
|-------|---------|
| **brainstorming** | Turns ideas into fully formed designs before implementation |
| **dispatching-parallel-agents** | Delegate independent tasks to specialized agents concurrently |
| **executing-plans** | Structured workflow for implementing written plans |
| **finishing-a-development-branch** | Verify tests, present options, clean up branches |
| **receiving-code-review** | Technical evaluation of code review feedback |
| **requesting-code-review** | Systematic code review request process |
| **subagent-driven-development** | Coordinate implementation via specialized subagents |
| **systematic-debugging** | Root cause investigation before fixes |
| **test-driven-development** | Write test first, watch it fail, minimal code to pass |
| **using-git-worktrees** | Isolated workspaces for feature development |
| **using-superpowers** | How to find and use skills in any conversation |
| **verification-before-completion** | Evidence before claims, always |
| **writing-plans** | Create detailed implementation plans |
| **writing-skills** | TDD applied to process documentation |

### Commands
- `brainstorm.md` - Brainstorming command (redirects to skill)
- `execute-plan.md` - Plan execution command (redirects to skill)
- `write-plan.md` - Plan writing command (redirects to skill)

### Agents
- `code-reviewer.md` - Senior code reviewer agent definition

### Hooks
- `hooks.json` - Session start hook configuration
- `session-start` - Session initialization script

## How to Use

1. Copy the `skills/` directory into your project or `~/.claude/skills`
2. Configure hooks if desired
3. Reference skills in your CLAUDE.md or invoke them directly

## Source
- Repository: https://github.com/obra/superpowers
- License: MIT
