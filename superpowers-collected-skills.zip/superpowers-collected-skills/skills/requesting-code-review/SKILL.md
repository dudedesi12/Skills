---
name: requesting-code-review
description: Use after completing each task in subagent-driven development and before merging to main - systematic code review request process
---

# Requesting Code Review

## Overview

Reviews are mandatory after each task in subagent-driven development and before merging to main. Also valuable when stuck or before refactoring.

**Core principle:** Review early, review often. This prevents issues from compounding and keeps reviewers focused on the work product rather than session history.

## The Process

1. Obtain git SHAs for the changes to review
2. Dispatch the code-reviewer subagent with a filled template
3. Act on feedback: Critical issues require immediate fixes, important issues should be resolved before proceeding

## Red Flags

- Skipping reviews for seemingly simple tasks
- Ignoring critical issues
- Proceeding without fixing important problems

However, push back on feedback you believe is incorrect, supported by technical evidence.
