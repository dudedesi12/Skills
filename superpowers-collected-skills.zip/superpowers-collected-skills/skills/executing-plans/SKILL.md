---
name: executing-plans
description: Use when you have a written implementation plan and need to execute it systematically with review checkpoints
---

# Executing Plans

## Overview

Structured workflow for implementing written plans with review checkpoints.

**Announce at start:** "I'm using the executing-plans skill to implement this plan."

## The Process

### Step 1: Load and Review

- Read the plan critically
- Identify concerns and raise them before starting execution
- Don't begin implementation without explicit consent to use non-main branches

### Step 2: Execute Tasks

- Work through each task sequentially
- Mark progress using TodoWrite
- Run specified verifications after each task
- Stop and request clarification when encountering blockers, missing dependencies, test failures, or unclear instructions
- Never force through obstacles or make assumptions

### Step 3: Complete Development

- Use the finishing-a-development-branch skill to verify tests and present options
- Announce: "I'm using the finishing-a-development-branch skill to complete this work."

## Critical Guidelines

- **Review plan critically first** - Don't blindly follow a flawed plan
- **Don't skip verifications** - Run tests after each task
- **Ask for clarification rather than guessing** - Stop when encountering blockers
- **Never begin on main/master** without explicit user consent

## Required Integration

- **using-git-worktrees** - REQUIRED before executing tasks (isolated workspace)
- **writing-plans** - Creates the plan being executed
- **finishing-a-development-branch** - Completes the work

**Note:** Subagent-driven development produces significantly higher quality results when subagent support is available on the platform.
