# Condition-Based Waiting

## Overview

Wait for the actual condition you care about, not a guess about how long it takes.

## When to Use

- Tests contain arbitrary delays (setTimeout, sleep)
- Tests exhibit flakiness
- NOT when testing actual timing behavior (debounce intervals)

## Core Pattern

**Bad:**
```typescript
await new Promise(r => setTimeout(r, 50));
expect(items.length).toBe(3);
```

**Good:**
```typescript
await waitFor(() => items.length === 3, 'Expected 3 items');
expect(items.length).toBe(3);
```

## Generic Polling Function

```typescript
async function waitFor(
  condition: () => boolean,
  description: string,
  timeoutMs = 5000
): Promise<void> {
  const start = Date.now();
  while (!condition()) {
    if (Date.now() - start > timeoutMs) {
      throw new Error(`Timeout: ${description} after ${timeoutMs}ms`);
    }
    await new Promise(r => setTimeout(r, 10));
  }
}
```

## Quick Patterns

| Scenario | Pattern |
|----------|---------|
| Wait for event | `waitFor(() => events.includes(type))` |
| Wait for state | `waitFor(() => state === expected)` |
| Wait for count | `waitFor(() => items.length >= n)` |
| Wait for file | `waitFor(() => existsSync(path))` |

## Common Mistakes

- Polling every 1ms (wasteful)
- Omitting timeouts (test hangs forever)
- Using stale cached data instead of fresh values

## When Arbitrary Timeouts Are Acceptable

After conditions are met, if documented with reasoning (e.g., "200ms = 2 ticks at 100ms intervals").

## Real-World Impact

- Pass rate: 60% → 100%
- Execution time: 40% faster
