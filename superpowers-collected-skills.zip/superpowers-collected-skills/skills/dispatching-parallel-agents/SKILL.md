---
name: dispatching-parallel-agents
description: Use when facing 2+ independent tasks that can be worked on without shared state or sequential dependencies
---

# Dispatching Parallel Agents

## Overview

This pattern involves delegating separate tasks to specialized agents with isolated context. The key principle is dispatching one agent per independent problem domain to enable concurrent work, avoiding sequential investigation of unrelated failures across different test files or subsystems.

## When to Use

The decision framework involves three questions:
1. Are there multiple failures?
2. Are they independent (not related)?
3. Can they work in parallel without shared state?

**Use this pattern when:**
- Multiple test files fail with different root causes
- Independent subsystems are broken
- Each problem is understandable in isolation
- No shared state exists between investigations

**Avoid when:**
- Failures are interconnected
- Full system context is necessary
- Agents would interfere with each other's work

## The Pattern

**1. Identify Independent Domains** - Group failures by affected component

**2. Create Focused Tasks** - Each agent receives specific scope, clear goal, defined constraints, and expected output format

**3. Dispatch in Parallel** - Launch all agents simultaneously rather than sequentially

**4. Review and Integrate** - Examine summaries, verify no conflicts, run complete test suite

## Agent Prompt Guidelines

Effective prompts are focused on one domain, self-contained with necessary context, and explicit about deliverables. "Do NOT just increase timeouts - find the real issue."

## Key Benefits

- **Parallelization** enables simultaneous investigation
- **Focused scope** reduces cognitive load per agent
- **Independence** prevents interference
- **Speed** solves multiple problems concurrently rather than sequentially

Real-world impact: 6 failures across 3 files resolved by 3 parallel agents with zero conflicts.
