---
name: writing-skills
description: Use when creating new skills, editing existing skills, or verifying skills work before deployment
---

# Writing Skills

## Overview

**Writing skills IS Test-Driven Development applied to process documentation.**

You write test cases (pressure scenarios with subagents), watch them fail (baseline behavior), write the skill (documentation), watch tests pass (agents comply), and refactor (close loopholes).

**Core principle:** If you didn't watch an agent fail without the skill, you don't know if the skill teaches the right thing.

## What is a Skill?

A **skill** is a reference guide for proven techniques, patterns, or tools.

**Skills are:** Reusable techniques, patterns, tools, reference guides
**Skills are NOT:** Narratives about how you solved a problem once

## When to Create a Skill

**Create when:**
- Technique wasn't intuitively obvious
- You'd reference this again across projects
- Pattern applies broadly (not project-specific)

**Don't create for:**
- One-off solutions
- Standard practices well-documented elsewhere
- Project-specific conventions (put in CLAUDE.md)

## SKILL.md Structure

**Frontmatter (YAML):**
- `name`: Use letters, numbers, hyphens only
- `description`: Start with "Use when..." (triggering conditions only, NOT workflow summary)

**Body sections:**
- Overview with core principle
- When to Use
- Core Pattern
- Quick Reference
- Common Mistakes
- Red Flags

## The Iron Law (Same as TDD)

```
NO SKILL WITHOUT A FAILING TEST FIRST
```

## RED-GREEN-REFACTOR for Skills

### RED: Baseline
Run pressure scenario WITHOUT the skill. Document exact behavior and rationalizations.

### GREEN: Write Minimal Skill
Write skill addressing those specific rationalizations. Re-test - agent should now comply.

### REFACTOR: Close Loopholes
Agent found new rationalization? Add explicit counter. Re-test until bulletproof.

## Testing Checklist

**RED Phase:**
- [ ] Created pressure scenarios (3+ combined pressures)
- [ ] Ran scenarios WITHOUT skill
- [ ] Documented failures verbatim

**GREEN Phase:**
- [ ] Description starts with "Use when..." (no workflow summary)
- [ ] Keywords throughout for search
- [ ] Run scenarios WITH skill - verify compliance

**REFACTOR Phase:**
- [ ] Identify NEW rationalizations
- [ ] Add explicit counters
- [ ] Build rationalization table
- [ ] Re-test until bulletproof

## Supporting Files

- **anthropic-best-practices.md** - Official skill authoring best practices
- **testing-skills-with-subagents.md** - Complete testing methodology
- **persuasion-principles.md** - Research on effective skill design
- **graphviz-conventions.dot** - Flowchart style guide
