# Persuasion Principles for Skill Design

## Overview

LLMs respond to the same persuasion principles as humans. Understanding this psychology helps design more effective skills.

**Research foundation:** Meincke et al. (2025) - "Persuasion techniques more than doubled compliance rates (33% to 72%, p < .001)."

## The Seven Principles

### 1. Authority
Imperative language: "YOU MUST", "Never", "Always". Eliminates decision fatigue and rationalization.

### 2. Commitment
Require announcements, force explicit choices, use tracking (TodoWrite for checklists).

### 3. Scarcity
Time-bound requirements: "Before proceeding", "Immediately after X". Prevents procrastination.

### 4. Social Proof
Universal patterns: "Every time", "Always". Establishes norms.

### 5. Unity
Shared identity: "our codebase", "we're colleagues". Best for collaborative workflows.

### 6. Reciprocity
Use sparingly - can feel manipulative. Rarely needed in skills.

### 7. Liking
DON'T USE for compliance. Creates sycophancy.

## Principle Combinations by Skill Type

| Skill Type | Use | Avoid |
|------------|-----|-------|
| Discipline-enforcing | Authority + Commitment + Social Proof | Liking, Reciprocity |
| Guidance/technique | Moderate Authority + Unity | Heavy authority |
| Collaborative | Unity + Commitment | Authority, Liking |
| Reference | Clarity only | All persuasion |

## Ethical Use

**The test:** Would this technique serve the user's genuine interests if they fully understood it?

## Citations

- Cialdini, R. B. (2021). Influence: The Psychology of Persuasion. Harper Business.
- Meincke, L. et al. (2025). Call Me A Jerk: Persuading AI to Comply. University of Pennsylvania.
