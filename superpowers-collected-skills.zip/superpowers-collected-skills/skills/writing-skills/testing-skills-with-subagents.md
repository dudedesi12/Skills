# Testing Skills With Subagents

**Testing skills is just TDD applied to process documentation.**

## Overview

Run scenarios without the skill (RED), write skill addressing failures (GREEN), close loopholes (REFACTOR).

## TDD Mapping

| TDD Phase | Skill Testing |
|-----------|---------------|
| **RED** | Run scenario WITHOUT skill, watch agent fail |
| **Verify RED** | Capture rationalizations verbatim |
| **GREEN** | Write skill addressing specific failures |
| **Verify GREEN** | Run scenario WITH skill, verify compliance |
| **REFACTOR** | Find new rationalizations, add counters |

## Writing Pressure Scenarios

**Bad (no pressure):** "What does the skill say?"
**Good (multiple pressures):** Combine 3+ pressures:

| Pressure | Example |
|----------|---------|
| Time | Emergency, deadline, deploy window |
| Sunk cost | Hours of work to delete |
| Authority | Senior says skip it |
| Exhaustion | End of day, want to go home |
| Social | Looking dogmatic |
| Pragmatic | "Being pragmatic vs dogmatic" |

## Plugging Loopholes

For each new rationalization:
1. Explicit negation in rules
2. Entry in rationalization table
3. Red flag entry
4. Update description with violation symptoms

## When Skill is Bulletproof

- Agent chooses correct option under maximum pressure
- Agent cites skill sections as justification
- Agent acknowledges temptation but follows rule
- Meta-testing reveals "skill was clear"
