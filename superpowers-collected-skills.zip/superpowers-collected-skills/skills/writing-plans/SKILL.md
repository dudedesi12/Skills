---
name: writing-plans
description: Use when you have a validated design/spec and need to create a detailed implementation plan with task-by-task breakdown
---

# Writing Plans

## Overview

Create detailed, task-by-task implementation plans for multi-step features. Plans are written for engineers with strong coding skills but minimal context about your codebase.

**Core principle:** Every step must include actual code, exact file paths, and specific commands. No placeholders.

## Key Requirements

- Every plan starts with a standardized header (goal, architecture, tech stack)
- Tasks use checkbox syntax with exact file paths, complete code blocks, precise commands
- No placeholders like "TBD", "add validation", or vague references
- Plans save to `docs/superpowers/plans/YYYY-MM-DD-<feature-name>.md`

## Task Granularity

Each step is one atomic action:
- Write test
- Run it (verify failure)
- Implement
- Verify pass
- Commit

Code examples are complete and exact, never "similar to Task N."

## Task Structure

Tasks are 2-5 minutes each, following TDD:
1. Write failing test
2. Implement to pass
3. Verify
4. Commit

## File Structure Design

- Design focused units with clear boundaries
- Smaller, focused files over large ones
- Code you can hold in context at once

## Before Handoff - Self Review

1. **Spec coverage** - Does the plan cover all spec requirements?
2. **Placeholder scan** - Any TBD, TODO, or incomplete sections?
3. **Type consistency** - Are types consistent across tasks?

## Execution Options

After plan completion, offer two approaches:
1. **Subagent-driven** - Fresh agent per task (higher quality)
2. **Inline execution** - Execute with checkpoints in current session

## Integration

- **brainstorming** - Creates the spec that feeds into this plan
- **executing-plans** - Executes the plan created here
- **subagent-driven-development** - Alternative execution approach
