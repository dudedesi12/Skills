---
name: subagent-driven-development
description: Use when executing implementation plans with independent tasks in the current session
---

# Subagent-Driven Development

## Overview

Coordinate implementation work by dispatching specialized subagents for each task, with mandatory two-stage review (spec compliance first, then code quality).

**Core principle:** Fresh subagent per task + two-stage review (spec then quality) = high quality, fast iteration.

Each subagent receives precisely constructed instructions without inheriting session history, preventing context pollution while preserving the controller's coordination capacity.

## When to Use

- A clear implementation plan with discrete tasks
- Tasks that are mostly independent rather than tightly coupled
- A preference to remain in the current session

If tasks are tightly coupled, consider the parallel-session alternative instead.

## The Workflow Per Task

1. **Dispatch implementer subagent** with complete task context
2. **Address any clarification questions** before work begins
3. **Spec compliance review** (checking requirement alignment)
4. **Code quality review** (assessing implementation standards)
5. **Iterative fixes** if issues arise
6. **Mark task complete** and proceed to next

## Implementer Status Types

- **DONE** - Task completed successfully
- **DONE_WITH_CONCERNS** - Completed but has questions/concerns
- **NEEDS_CONTEXT** - Requires additional information
- **BLOCKED** - Cannot proceed without help

## Model Selection Strategy

Match model capability to task complexity:
- **Mechanical implementation** (1-2 files, clear specs): cheaper models
- **Integration work**: standard models
- **Architectural decisions**: most capable available

## Critical Safeguards

**Never:**
- Skip review stages
- Proceed with unfixed issues
- Make subagents read plan files directly
- Ignore subagent questions

**Always:**
- Complete spec compliance review before code quality review
- Address BLOCKED status by investigating root cause
- Provide full context in each subagent prompt
